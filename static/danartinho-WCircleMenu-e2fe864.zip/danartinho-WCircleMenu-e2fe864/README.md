WCircleMenu
===========

jQuery plugin to create a circle Path-like menu

Plugin documentation and examples : http://danartinho.github.io/WCircleMenu/
